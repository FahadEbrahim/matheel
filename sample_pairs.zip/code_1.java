import java.util.Arrays;
import java.util.List;

public class max {
   public static void main(String[] args){
      List<Integer> arrayList = Arrays.asList(10, 5, 1, 20, 100);
      int max = Integer.MIN_VALUE;
      for (Integer i : arrayList) {
         if (i > max)
         max = i;
      }
      System.out.println(max);
   }
}