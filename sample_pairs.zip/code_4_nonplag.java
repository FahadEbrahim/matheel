import java.util.*;
public class maxCollection{
   public static void main(String[] args){
      int array[] = {10, 5, 1, 20, 100};
      List<Integer> list = new ArrayList<>();
      for(int a=0;a<array.length;a++){
         list.add(array[a]);
      }
      System.out.println(Collections.max(list));
   }
} 