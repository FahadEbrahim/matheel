import java.util.Arrays;
import java.util.List;

public class maxi {
public static void main(String[] args)
{
    System.out.println();
    List<Integer> aa = Arrays.asList(10, 5, 1, 20, 100);
    int mm = Integer.MIN_VALUE;
    System.out.println();
    for (Integer i : aa) 
    {if (i > mm)    mm = i;}
System.out.println(mm);
}}