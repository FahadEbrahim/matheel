import java.util.*;





public class ma {
public static void main(String[] args)
{List<Integer> a = Arrays.asList(10, 5, 1, 20, 100);
int m = Integer.MIN_VALUE;
for (Integer i : arrayList) 
{if (i > m)
m = i;}
System.out.println(m);}}